export * from "./ui/forbidden-page";
