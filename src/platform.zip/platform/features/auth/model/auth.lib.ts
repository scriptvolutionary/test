import { sessionKeys } from "@/platform/entities/session";
import { useAuthStore } from "@/platform/features/auth/model/auth.store";
import { queryClient } from "@/platform/infra/query";

export function logout() {
	useAuthStore.getState().clearToken();
	queryClient.setQueryData(sessionKeys.me(), null);
}
