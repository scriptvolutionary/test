export {
	baseHttp,
	http,
	setHttpModuleResolver,
	type ModuleResolver
} from '@/platform/infra/http'
