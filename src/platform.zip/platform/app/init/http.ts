import { setHttpModuleResolver } from "@/platform/infra/http";

import { useAppStore } from "../state";

export const initHttpSync = () => {
	setHttpModuleResolver(() => useAppStore.getState().module);
};
