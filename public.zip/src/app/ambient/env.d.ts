declare const __APP_VERSION__: string
declare const __USE_SLI__: boolean
declare const __API_HOST__: string
declare const __API_PORT__: string
declare const __DEBUG_MODE__: boolean
declare const __ENABLED_MODULES__: Array<'agroservice' | 'csoo'>
