declare const __API_HOST__: string;
declare const __API_PORT__: string;
declare const __ENV__: "development" | "production";
declare const __DEBUG_MODE__: boolean;
declare const __ENABLED_MODULES__: Array<"agro" | "csoo">;
