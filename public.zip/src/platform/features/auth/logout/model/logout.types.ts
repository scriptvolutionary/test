import type { ApiResponse } from '@/shared/types/api-response'

export type LogoutResponse = ApiResponse<null>
