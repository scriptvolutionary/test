﻿import { useNavigate, useSearch } from '@tanstack/react-router'

import { LoginForm } from '@/platform/features/auth/login/ui/login-form'
import { AuthPageShell } from '@/platform/pages/auth/_ui'

export function LoginPageComponent() {
	const navigate = useNavigate()
	const search = useSearch({ from: '/log-in' })

	return (
		<AuthPageShell
			title='РџРѕР»СѓС‡РёС‚Рµ РґРѕСЃС‚СѓРї'
			description='Р’РѕР№РґРёС‚Рµ РІ СЃРІРѕСЋ СѓС‡РµС‚РЅСѓСЋ Р·Р°РїРёСЃСЊ РёСЃРїРѕР»СЊР·СѓСЏ СЌР»РµРєС‚СЂРѕРЅРЅСѓСЋ РїРѕС‡С‚Сѓ Рё РїР°СЂРѕР»СЊ'
		>
			<LoginForm onSuccess={() => navigate({ to: search.redirect ?? '/platform' })} />
		</AuthPageShell>
	)
}
