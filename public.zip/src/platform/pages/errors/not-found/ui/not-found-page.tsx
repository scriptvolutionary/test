﻿import { ModuleFeedbackButton } from '@/platform/core/ui/module-feedback-button'
import { ErrorPageShell } from '@/platform/pages/errors/_ui'

export function NotFoundPageComponent() {
	return (
		<ErrorPageShell
			title='404'
			description='РџРѕ РІСЃРµР№ РІРёРґРёРјРѕСЃС‚Рё С‚РµРєСѓС‰Р°СЏ СЃС‚СЂР°РЅРёС†Р° РЅРµ СЃСѓС‰РµСЃС‚РІСѓРµС‚ РёР»Рё Р±С‹Р»Р° СѓРґР°Р»РµРЅР°.'
			headerAction={
				<ModuleFeedbackButton
					variant='ghost'
					report={{
						code: 404,
						title: 'РџСЂРѕРёР·РѕС€Р»Р° РѕС€РёР±РєР° РїСЂРё РѕС‚РєСЂС‹С‚РёРё СЃС‚СЂР°РЅРёС†С‹.'
					}}
				/>
			}
		/>
	)
}
