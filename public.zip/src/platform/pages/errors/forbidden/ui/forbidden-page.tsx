﻿import { useSearch } from '@tanstack/react-router'

import { ModuleFeedbackButton } from '@/platform/core/ui/module-feedback-button'
import { ErrorPageShell } from '@/platform/pages/errors/_ui'

export function ForbiddenPageComponent() {
	const { from } = useSearch({ from: '/forbidden' })

	return (
		<ErrorPageShell
			title='403'
			description='РЈ РІР°СЃ РЅРµС‚ РїСЂР°РІ РґР»СЏ РїСЂРѕСЃРјРѕС‚СЂР° СЌС‚РѕР№ СЃС‚СЂР°РЅРёС†С‹. Р•СЃР»Рё РІС‹ СЃС‡РёС‚Р°РµС‚Рµ С‡С‚Рѕ СЌС‚Рѕ РѕС€РёР±РєР° - РѕР±СЂР°С‚РёС‚РµСЃСЊ Рє РІР°С€РµРјСѓ Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.'
			headerAction={
				<ModuleFeedbackButton
					variant='ghost'
					url={location.href}
					report={{
						code: 403,
						title: 'РџСЂРѕРёР·РѕС€Р»Р° РѕС€РёР±РєР° РІ РїСЂРёР»РѕР¶РµРЅРёРё.',
						details: from ? `Р·Р°РїСЂР°С€РёРІР°РµРјС‹Р№ СЂРµСЃСѓСЂСЃ: ${from}` : undefined
					}}
				/>
			}
		/>
	)
}
