﻿import { useLocation } from '@tanstack/react-router'

import { ModuleFeedbackButton } from '@/platform/core/ui/module-feedback-button'

import { ErrorPageShell } from '../../_ui'

function getErrorMessage(error: unknown) {
	if (error instanceof Error) return error.message
	if (typeof error === 'string') return error
	return 'РќРµРёР·РІРµСЃС‚РЅР°СЏ РѕС€РёР±РєР°'
}

type Props = {
	error: unknown
}

export function ErrorPageComponent({ error }: Props) {
	const location = useLocation()
	const message = getErrorMessage(error)

	return (
		<ErrorPageShell
			title='500'
			description='Р§С‚Рѕ-С‚Рѕ РїРѕС€Р»Рѕ РЅРµ С‚Р°Рє. РџРѕРїСЂРѕР±СѓР№С‚Рµ РѕР±РЅРѕРІРёС‚СЊ СЃС‚СЂР°РЅРёС†Сѓ РёР»Рё РІРµСЂРЅСѓС‚СЊСЃСЏ РІ РїСЂРёР»РѕР¶РµРЅРёРµ.'
			headerAction={
				<ModuleFeedbackButton
					url={location.href}
					report={{
						code: 500,
						title: 'РџСЂРѕРёР·РѕС€Р»Р° РѕС€РёР±РєР° РІ РїСЂРёР»РѕР¶РµРЅРёРё.',
						details: message
					}}
				/>
			}
		/>
	)
}
