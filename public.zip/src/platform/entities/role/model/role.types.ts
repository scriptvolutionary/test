import type { IdSysnameName } from '@/shared/types/base-entities'

export type Role = IdSysnameName
