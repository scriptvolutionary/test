export { queryClient } from "@/platform/infra/query";
