export * from '@/platform/core/init'
