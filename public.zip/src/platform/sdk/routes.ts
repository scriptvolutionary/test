export {
	moduleRoute,
	platformRoute,
	platformRouteTree,
	publicRouteTree,
	rootRoute
} from '@/platform/core/routes'
