export { isModuleEnabled, type Module } from '@/platform/infra/config'
