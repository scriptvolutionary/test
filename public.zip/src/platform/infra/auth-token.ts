import Cookies from "js-cookie";

import { runtime } from "./config";

const TOKEN_COOKIE_KEY = "token";

export function getAuthToken(): string | null {
	return Cookies.get(TOKEN_COOKIE_KEY) ?? null;
}

export function setAuthToken(token: string): void {
	Cookies.set(TOKEN_COOKIE_KEY, token, {
		sameSite: "lax",
		secure: runtime.env === "production",
	});
}

export function clearAuthToken(): void {
	Cookies.remove(TOKEN_COOKIE_KEY);
}
