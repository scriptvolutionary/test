export { baseHttp, http } from "@/platform/infra/http";
