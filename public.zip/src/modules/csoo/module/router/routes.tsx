﻿import { createRoute, Outlet } from '@tanstack/react-router'

import { defineHead } from '@/shared/lib/seo'

import { moduleRoute } from '@/platform/sdk/routes'

export const rootRoute = createRoute({
	getParentRoute: () => moduleRoute,
	path: 'csoo',
	head: defineHead({ title: 'Р¦РЎРћРћ' }),
	component: Outlet
})

export const indexRoute = createRoute({
	getParentRoute: () => rootRoute,
	path: '/',
	staticData: { crumb: 'Р“Р»Р°РІРЅР°СЏ' },
	head: defineHead({ title: 'Р¦РЎРћРћ В· Р“Р»Р°РІРЅР°СЏ' }),
	component: () => <div>CSOO</div>
})
