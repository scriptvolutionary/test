import { indexRoute, rootRoute } from './routes'

export const routeTree = rootRoute.addChildren([indexRoute])
