import { rootRoute } from "./routes";

export const routeTree = rootRoute;
