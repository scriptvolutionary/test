export const vMsg = {
	required: "Обязательное поле.",
	emailInvalid: "Электронная почта невалидна.",
	passwordMin8: "Пароль не может быть короче 8 символов.",
} as const;
