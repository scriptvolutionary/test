import { cva, type VariantProps } from 'class-variance-authority'

import { cn } from '@/shared/lib/utils'

function Empty({
	className,
	test,
	...props
}: React.ComponentProps<'div'> & { test?: string }) {
	return (
		<div
			data-slot="empty"
			date-test={test}
			className={cn(
				'gap-4 rounded-lg border-dashed p-6 flex w-full min-w-0 flex-1 flex-col items-center justify-center text-center text-balance',
				className
			)}
			{...props}
		/>
	)
}

function EmptyHeader({
	className,
	test,
	...props
}: React.ComponentProps<'div'> & { test?: string }) {
	return (
		<div
			data-slot="empty-header"
			date-test={test}
			className={cn('gap-2 flex max-w-sm flex-col items-center', className)}
			{...props}
		/>
	)
}

const emptyMediaVariants = cva(
	'mb-2 flex shrink-0 items-center justify-center [&_svg]:pointer-events-none [&_svg]:shrink-0',
	{
		variants: {
			variant: {
				default: 'bg-transparent',
				icon: "bg-muted text-foreground flex size-8 shrink-0 items-center justify-center rounded-lg [&_svg:not([class*='size-'])]:size-4"
			}
		},
		defaultVariants: {
			variant: 'default'
		}
	}
)

function EmptyMedia({
	className,
	test,
	variant = 'default',
	...props
}: React.ComponentProps<'div'> &
	VariantProps<typeof emptyMediaVariants> & { test?: string }) {
	return (
		<div
			data-slot="empty-icon"
			date-test={test}
			data-variant={variant}
			className={cn(emptyMediaVariants({ variant, className }))}
			{...props}
		/>
	)
}

function EmptyTitle({
	className,
	test,
	...props
}: React.ComponentProps<'div'> & { test?: string }) {
	return (
		<div
			data-slot="empty-title"
			date-test={test}
			className={cn('text-sm font-medium tracking-tight', className)}
			{...props}
		/>
	)
}

function EmptyDescription({
	className,
	test,
	...props
}: React.ComponentProps<'p'> & { test?: string }) {
	return (
		<div
			data-slot="empty-description"
			date-test={test}
			className={cn(
				'text-sm/relaxed text-muted-foreground [&>a:hover]:text-primary [&>a]:underline [&>a]:underline-offset-4',
				className
			)}
			{...props}
		/>
	)
}

function EmptyContent({
	className,
	test,
	...props
}: React.ComponentProps<'div'> & { test?: string }) {
	return (
		<div
			data-slot="empty-content"
			data-test={test}
			className={cn(
				'gap-2.5 text-sm flex w-full max-w-sm min-w-0 flex-col items-center text-balance',
				className
			)}
			{...props}
		/>
	)
}

export {
	Empty,
	EmptyContent,
	EmptyDescription,
	EmptyHeader,
	EmptyMedia,
	EmptyTitle
}
