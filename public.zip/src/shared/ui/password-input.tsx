﻿import { EyeIcon, EyeOffIcon, LockIcon } from 'lucide-react'
import * as React from 'react'

import { cn } from '../lib/utils'
import {
	InputGroup,
	InputGroupAddon,
	InputGroupButton,
	InputGroupInput
} from './primitives/input-group'

type Props = Omit<React.ComponentProps<typeof InputGroupInput>, 'type'> & {
	defaultShow?: boolean
	icon?: boolean
}

export function PasswordInput({ defaultShow = false, icon = true, ...props }: Props) {
	const [show, setShow] = React.useState(defaultShow)

	const masked = !show

	return (
		<InputGroup>
			{icon && (
				<InputGroupAddon>
					<LockIcon className='size-4' />
				</InputGroupAddon>
			)}

			<InputGroupInput
				type='text'
				autoComplete='current-password'
				placeholder='вЂўвЂўвЂўвЂўвЂўвЂўвЂўвЂў'
				className={cn(
					masked && 'text tracking-widest [-webkit-text-security:disc] placeholder:text-body'
				)}
				{...props}
			/>

			<InputGroupAddon align='inline-end'>
				<InputGroupButton
					type='button'
					size='icon-xs'
					aria-label={show ? 'РЎРєСЂС‹С‚СЊ РїР°СЂРѕР»СЊ' : 'РџРѕРєР°Р·Р°С‚СЊ РїР°СЂРѕР»СЊ'}
					onClick={() => setShow((v) => !v)}
					disabled={props.disabled}
				>
					{show ? <EyeOffIcon className='size-4' /> : <EyeIcon className='size-4' />}
				</InputGroupButton>
			</InputGroupAddon>
		</InputGroup>
	)
}
